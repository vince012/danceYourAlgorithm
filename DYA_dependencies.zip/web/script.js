class CostumeStage{
	constructor(){
		this.assetId= "cd21514d0531fdffb22204e0ec5ed84a";
		this.name= "backdrop1";
		this.md5ext= "cd21514d0531fdffb22204e0ec5ed84a.svg";
		this.dataFormat= "svg";
		this.rotationCenterX= 0;
		this.rotationCenterY= 0;
	}
}

Array.prototype.remove = function(from,to) {
  var rest = this.slice((to || from) + 1 || this.length);
  this.length = from < 0 ? this.length + from : from;
  return this.push.apply(this,rest);
};
// les classes...
class Costume{
	constructor(assetId,name,bitmapResolution,md5ext,dataFormat,rotationCenterX,rotationCenterY){
		this.assetId= assetId;
		this.name= name;		
		this.bitmapResolution= bitmapResolution;
		this.md5ext= md5ext;
		this.dataFormat= dataFormat;
		this.rotationCenterX= rotationCenterX;
		this.rotationCenterY= rotationCenterY;
	}
}

class SoundStage{
	constructor(){
		this.assetId= "83a9787d4cb6f3b7632b4ddfebf74367";
		this.name= "pop";
		this.dataFormat= "wav";
		this.format= "";
		this.rate= 48000,
		this.sampleCount= 1032;
		this.md5ext= "83a9787d4cb6f3b7632b4ddfebf74367.wav";
	}
}

class Sound{
	constructor(assetId,name,dataFormat,format,rate,sampleCount,md5ext){
		this.assetId= assetId;
		this.name= name;
		this.dataFormat= dataFormat;
		this.format= format;
		this.rate= rate;
		this.sampleCount= sampleCount;
		this.md5ext= md5ext;
	}
}

class BlockWithId{
	constructor(id,block){
		var idU = generateId();
		this.id = ( (id == 0) ? idU : id);
		this.block = block;
		if(id == 0) console.log(idU);
		else console.log(id);
	}
	next(next){
		if(this.block.acceptNext){
			this.block.next = next.id;
			next.block.parent = this.id;
		}
		else
			throw new Error("Block ga3ma kiAccepté next");
	}
	parent(parent){
		this.block.parent = parent.id;
		parent.block.next = this.id;
	}
	onlyParentById(id){
		this.block.parent = id;
	}
}

class Block{
	constructor(opcode,next,parent,inputs,fields,topLevel,shadow){
		this.opcode = opcode;
		this.next = next;
		this.parent = parent;
		this.inputs = inputs;
		this.fields = fields;
		this.topLevel = topLevel;
		this.shadow = shadow;
		this.acceptNext = true;
		Object.defineProperty(this,'acceptNext',{
			enumerable: false
		});
	}
}

class BlockEvent extends Block{
	constructor(opcode,next,parent,inputs,fields,topLevel,shadow,x,y){
		super(opcode,next,parent,inputs,fields,topLevel,shadow);
		this.x = x;
		this.y = y;
	}
}

class FlagGreen extends BlockEvent{
	constructor(){
		super("event_whenflagclicked",null,null,{},{},true,false,135,129);
	}
}

class Backdrop extends Block{
	constructor(backdrop){
		var inputs =  {};
		var fields =  {BACKDROP: [backdrop]};		
		super("looks_backdrops",null,null,inputs,fields,false,true);
	}		
}


class SwitchToBackdrop extends Block{
	constructor(id){		
		var inputs =  {BACKDROP: [1,id]};
		var fields =  {};		
		super("looks_switchbackdropto",null,null,inputs,fields,false,false);
	}		
}

class Changexby extends Block{
	constructor(distanceX){
		if(distanceX == null) distanceX = 10;
		var inputs =  {
			DX: [
				1,
				[4,distanceX.toString()]
			]
		};
		var fields =  {};
		super("motion_changexby",null,null,inputs,fields,false,false);
	}
}

class Changeyby extends Block{
	constructor(distanceX){
		if(distanceX == null) distanceX = 10;
		var inputs =  {
			DY: [
				1,
				[4,distanceX.toString()]
			]
		};
		var fields =  {};
		super("motion_changeyby",null,null,inputs,fields,false,false);
	}
}

class Gotoxy extends Block{
	constructor(X,Y){
		if(X==null||Y==null){
			X = -190;
			Y = -80;
		}
		var inputs = {
			X: [1,[4,X.toString()]],
			Y: [1,[4,Y.toString()]]
		};
		var fields = {};
		super("motion_gotoxy",null,null,inputs,fields,false,false);
	}
}

class PointInDirection extends Block {
	constructor(direction) {
		if (direction==null) {
			direction = 90;
		}
		var inputs = {DIRECTION: [1,[8,direction.toString()]]};
		var fields = {};
		super("motion_pointindirection",null,null,inputs,fields,false,false);
	}		
}

class SetRotationStyle extends Block {
	constructor(rotation_style) {
		if (rotation_style == null)
			rotation_style = "all around";		
		var inputs = {};
		var fields = {STYLE: [rotation_style]};						
		super("motion_setrotationstyle",null,null,inputs,fields,false,false);			
	}	
}

class SwitchCostumeTo extends Block {
	constructor(id) {			
			var inputs = {COSTUME: [1,id]};
			var fields = {};
			super("looks_switchcostumeto",null,null,inputs,fields,false,false);						
	}		
}

class LooksCostume extends Block {
	constructor(costume) {		
			var inputs = {};	
			var fields = {COSTUME: [costume]};			
			super("looks_costume",null,null,inputs,fields,false,false);						
	}
}

class TurnRight extends Block {
	constructor(degree){
		if(degree == null) degree = 15;
		var inputs = {
			DEGREES: [1,[4,degree.toString()]]
		};
		var fields = {};
		super("motion_turnright",null,null,inputs,fields,false,false);
	}
}

class TurnLeft extends Block {
	constructor(degree){
		if(degree == null) degree = 15;
		var inputs = {
			DEGREES: [1,[4,degree.toString()]]
		};
		var fields = {};
		super("motion_turnleft",null,null,inputs,fields,false,false);
	}
} 

class ControlRepeat extends Block {
	constructor(time,arrayBlock,id){
		if(arrayBlock == null || !arrayBlock instanceof Array) throw new Error("Faut insérer un tableau dans ce type de Block");
		if(time==null || time <= 0) throw new Error("La valeur de time d'une boucle doit être positive");
		if(id == null) throw new Error("Faut insérer l'id de la boucle pour l'ajouter comme parent dans le 1er block");
		var switch_backdrop = false;
		if(arrayBlock.length > 0)
			arrayBlock[0].onlyParentById(id);
		var inputs = {
			TIMES: [1,[6,time.toString()]],
			SUBSTACK: [(arrayBlock.length != 0 ) ? 2 : 1,(arrayBlock.length != 0 ) ? arrayBlock[0].id : null]
		};
		
		if(arrayBlock.length > 1){
			for(var i = 1; i < arrayBlock.length; i++) {				
				if (arrayBlock[i].block.opcode == "looks_backdrops") {
					switch_backdrop = true;
					continue;
				}		

				if (switch_backdrop) {
					arrayBlock[i].parent(arrayBlock[i-2]);
					switch_backdrop = false;
				}
				else
					arrayBlock[i].parent(arrayBlock[i-1]);	
			}				
		}
		var fields = {};
		super("control_repeat",null,null,inputs,fields,false,false);
	}
}
	
class ControlForever extends Block {
	constructor(arrayBlock,id){
		if(arrayBlock == null || !arrayBlock instanceof Array) throw new Error("Faut insérer un tableau dans ce type de Block");
		if(id == null) throw new Error("Faut insérer l'id de la boucle pour l'ajouter comme parent dans le 1er block");
		if(arrayBlock.length == 0)
			var inputs = {};
		else{
			arrayBlock[0].onlyParentById(id);
			var inputs = {
				SUBSTACK: [2,arrayBlock[0].id]
			};
		}
		if(arrayBlock.length > 1){
			for(var i = 1; i < arrayBlock.length; i++)
				arrayBlock[i].parent(arrayBlock[i-1]);
		}
		var fields = {};
		super("control_forever",null,null,inputs,fields,false,false);
		this.acceptNext = false;
	}	
}

class ControlStop extends Block {
	constructor(option){
		var opt;
		if (option == null) opt = "all";
		if (option == "all" || option == "this script" || option == "other scripts in sprite1") opt = option;	
		else throw new Error("L'option doit être du type all,this script ou other scripts in sprite1");
		var inputs = {};
		var fields = {
			STOP_OPTION: [opt]
		};
		super("control_stop",null,null,inputs,fields,false,false);
		this.mutation = {
			tagName: "mutation",
			children: [],
			hasnext: "false"
		}
		this.acceptNext = false;
	}
}
class ControlWait extends Block {
	constructor(duration){
		if(duration == null) duration = 0.4;
		var inputs = {
			DURATION: [1,[5,duration.toString()]]
		};
		var fields = {};
		super("control_wait",null,null,inputs,fields,false,false);
	}
}

class ChangeCostumeSize extends Block {
	constructor(size) {
		if (size == null) size = 5;
		var inputs = {
		CHANGE: [1,[4,size.toString()]]
		};
		var fields = {};
		super("looks_changesizeby",null,null,inputs,fields,false,false);
	}
}

class ResetCostumeSize extends Block {
	constructor() {
		var inputs = {
		SIZE: [1,[4,"100"]]
		};
		var fields = {};
		super("looks_setsizeto",null,null,inputs,fields,false,false);
	}
}

class Show extends Block {
	constructor() {
		var inputs = {};
		var fields = {};
		super("looks_show",null,null,inputs,fields,false,false);
	}
}

class Hide extends Block {
	constructor() {
		var inputs = {};
		var fields = {};
		super("looks_hide",null,null,inputs,fields,false,false);
	}
}
class ControlIf extends Block {
	constructor(id_check,id_action) {
		if (id_action != null) {
			var inputs = {
				CONDITION: [2,id_check],
				SUBSTACK: [2,id_action]
			};
		}
		else {
			var inputs = {
				CONDITION: [2,id_check],
			};
		}
		var fields = {};
		super("control_if",null,null,inputs,fields,false,false);
	}		
}

class SensingTouchingObject extends Block {
	constructor(id) {
		var inputs = {
			TOUCHINGOBJECTMENU: [1,id]
		};
		var fields = {};
		super("sensing_touchingobject",null,null,inputs,fields,false,false);
	}	
}

class SensingTouchingObjectMenu extends Block {
	constructor(name) {
		var inputs = {};
		var fields = {
			TOUCHINGOBJECTMENU: [name]
		};
		super("sensing_touchingobjectmenu",null,null,inputs,fields,false,true);
	}	
}

class Target{
	constructor(isStage,name){
		this.isStage = isStage;
		this.name = name;
		this.variables = (isStage ? {"`jEk@4|i[#Fk?(8x)AV.-my variable": ["my variable",0]} : {});
		this.lists = {};
		this.broadcasts = {};
		this.blocks = {};	
		this.comments = {};		
		this.currentCostume = 0;
		
		if (isStage) {
			this.costumes = [
				new CostumeStage(),
				new Costume("e494c4f44897d94e0541f7036a302449","Basketball",1,"e494c4f44897d94e0541f7036a302449.svg","svg",240,180),
				new Costume("e2f8b0dbd0a65d2ad8bfc21616662a6a","Bedroom",2,"e2f8b0dbd0a65d2ad8bfc21616662a6a.png","png",480,360)
			]
		}
		else
			this.costumes = {};
		this.sounds = [(isStage ? new SoundStage() : {} )];
		this.volume = 100;		
	}
}

class Stage extends Target{
	constructor(isStage,name){
		super(isStage,name);
		this.tempo = 60;
		this.videoTransparency = 50;
		this.videoStat = "off";
	}
}

// variable statique pour attribuer la position de départ
// au sprite. on gère ici les x.
/* var incr = (function () {
    var i = -320;

    return function () {
        return i = i + 150;
    }
})(); */

class Sprite extends Target{
	constructor(isStage,name){
		super(isStage,name);
		this.visible = true;
		this.x = 0
		this.y = 0;
		this.size = 100;
		this.direction = 90;
		this.draggable = false;
		this.rotationStyle = "all around";
	}
}

function go(stat_1,stat_2) {
	var costume1_list = ["costume1","costume2"];
	var costume2_list = ["dog2-a","dog2-b","dog2-c"];
	
	var stage = new Stage(true,"Stage");	
	var sprite1 = new Sprite(false,"Sprite1");	
	var costume1_1 = new Costume("09dc888b0b7df19f70d81588ae73420e","costume1",1,"09dc888b0b7df19f70d81588ae73420e.svg","svg",47,55);
	var costume1_2 = new Costume("3696356a03a8d938318876a593572843","costume2",1,"3696356a03a8d938318876a593572843.svg","svg",47,55);	
	var meow = new Sound("83c36d806dc92327b9e7049a565c6bff","Meow","wav","",48000,40681,"83c36d806dc92327b9e7049a565c6bff.wav");
	sprite1.costumes = [costume1_1,costume1_2];
	sprite1.sounds = [meow];
	
	var object;
	
	if (stat_2 != null) {
		var sprite2 = new Sprite(false,"Dog2");
		var costume2_1 = new Costume("bbe5666f3b8766f62756b974959bc701","dog2-a",1,"bbe5666f3b8766f62756b974959bc701.svg","svg",75,75);
		var costume2_2 = new Costume("4e0b16a0f8d03bd260447927f697484f","dog2-b",1,"4e0b16a0f8d03bd260447927f697484f.svg","svg",75,75);
		var costume2_3 = new Costume("abdf5e5892e9801c0abfb2ee1ab5adc7","dog2-c",1,"abdf5e5892e9801c0abfb2ee1ab5adc7.svg","svg",75,75);
		var wouf = new Sound("b15adefc3c12f758b6dc6a045362532f","dog1","wav","",48000,7993,"b15adefc3c12f758b6dc6a045362532f.wav");
		sprite2.costumes = [costume2_1,costume2_2,costume2_3];
		sprite2.sounds = [wouf];
		
		sprite1 = GenerateSequencePerso(1,stat_1,sprite1,sprite2.name,costume1_list,costume2_list);
		sprite2 = GenerateSequencePerso(2,stat_2,sprite1.name,sprite2,costume1_list,costume2_list);
		
		objet = {
			targets: [
				stage,
				sprite1,
				sprite2
			],
			meta: {
				semver: "3.0.0",
				vm: "0.1.0-prerelease.1526929817",
				agent: "Script WaiiM"
			}
		};
	}
	else {
		sprite1 = GenerateSequencePerso(1,stat_1,sprite1,costume1_list,costume2_list);
		objet = {
			targets: [
				stage,
				sprite1
			],
			meta: {
				semver: "3.0.0",
				vm: "0.1.0-prerelease.1526929817",
				agent: "Script WaiiM"
			}
		};
	}		 
	document.getElementById('main').innerHTML = JSON.stringify(objet);	
}
// recherche fin de boucle (mot clé CloseRepeat)
function recherche_end_boucle(chaine,act) {
	var cur = 0;
	for (var i=act;i < chaine.length;i++) {
		if (chaine[i] == "CloseRepeat") {
			cur = i;
			break;
		}					
	}
	return cur;
}
// crée un bloc d'instruction en fonction de l'unité associée (valeur déplacement) et vitesse
// déplacement pour les blocs de mouvement
function create_block(mouvs,sprite,block_name,i,speed) {
	var block2;
	
	switch (block_name) {
		case "HandUp":
			if (i != null) {
				if (/^\d+$/.test(mouvs[i+1])) {
					if (parseInt(mouvs[i+1]) % 2 == 0) {																																	
						if (speed == 3) {
							block2 = new BlockWithId(0,new Changeyby(parseInt(mouvs[i+1])/2));
						}					
					}					
					else {
						if (speed == 3) {
							block2 = new BlockWithId(0,new Changeyby(Math.floor(parseInt(mouvs[i+1])/2)));
						}
					}
					
					if (speed == 2) {
						block2 = new BlockWithId(0,new Changeyby(2));
					}				
				}
				else {
					if (speed == 2) {
						block2 = new BlockWithId(0,new Changeyby(2));
					}
					else if (speed == 3) {
						block2 = new BlockWithId(0,new Changeyby(5));
					}
				}
				
				if (speed == 1) {
					block2 = new BlockWithId(0,new Changeyby(1));
				}
			}
			else
				block2 = new BlockWithId(0,new Changeyby());
		break;
		
		case "HandBottom":
			if (i != null) {
				if (/^\d+$/.test(mouvs[i+1])) {
					if (parseInt(mouvs[i+1]) % 2 == 0) {																																	
						if (speed == 3) {
							block2 = new BlockWithId(0,new Changeyby(-parseInt(mouvs[i+1])/2));
						}					
					}					
					else {
						if (speed == 3) {
							block2 = new BlockWithId(0,new Changeyby(-Math.floor(parseInt(mouvs[i+1])/2)));
						}
					}
					
					if (speed == 2) {
						block2 = new BlockWithId(0,new Changeyby(-2));
					}				
				}
				else {
					if (speed == 2) {
						block2 = new BlockWithId(0,new Changeyby(-2));
					}
					else if (speed == 3) {
						block2 = new BlockWithId(0,new Changeyby(-5));
					}
				}
				
				if (speed == 1) {
					block2 = new BlockWithId(0,new Changeyby(-1));
				}
			}
			else
				block2 = new BlockWithId(0,new Changeyby(-10)); 
		break;
		
		case "HandLeft":
			if (/^\d+$/.test(mouvs[i+1])) {
				if (parseInt(mouvs[i+1]) % 2 == 0) {																																	
					if (speed == 3) {
						block2 = new BlockWithId(0,new Changexby(-parseInt(mouvs[i+1])/2));
					}					
				}					
				else {
					if (speed == 3) {
						block2 = new BlockWithId(0,new Changexby(-Math.floor(parseInt(mouvs[i+1])/2)));
					}
				}
				
				if (speed == 2) {
					block2 = new BlockWithId(0,new Changexby(-2));
				}				
			}
			else {
				if (speed == 2) {
					block2 = new BlockWithId(0,new Changexby(-2));
				}
				else if (speed == 3) {
					block2 = new BlockWithId(0,new Changexby(-5));
				}
			}
			
			if (speed == 1) {
				block2 = new BlockWithId(0,new Changexby(-1));
			}
		break;
		
		case "HandRight":
			if (/^\d+$/.test(mouvs[i+1])) {
				if (parseInt(mouvs[i+1]) % 2 == 0) {																																	
					if (speed == 3) {
						block2 = new BlockWithId(0,new Changexby(parseInt(mouvs[i+1])/2));
					}					
				}					
				else {
					if (speed == 3) {
						block2 = new BlockWithId(0,new Changexby(Math.floor(parseInt(mouvs[i+1])/2)));
					}
				}
				
				if (speed == 2) {
					block2 = new BlockWithId(0,new Changexby(2));
				}				
			}
			else {
				if (speed == 2) {
					block2 = new BlockWithId(0,new Changexby(2));
				}
				else if (speed == 3) {
					block2 = new BlockWithId(0,new Changexby(5));
				}
			}
			
			if (speed == 1) {
				block2 = new BlockWithId(0,new Changexby(1));
			}
		break;
		
		case "TurnLeft":
			if (/^\d+$/.test(mouvs[i+1])) {
				if (parseInt(mouvs[i+1]) % 2 == 0) {																																	
					if (speed == 3) {
						block2 = new BlockWithId(0,new TurnLeft(parseInt(mouvs[i+1])/2));
					}					
				}					
				else {
					if (speed == 3) {
						block2 = new BlockWithId(0,new TurnLeft(Math.floor(parseInt(mouvs[i+1])/2)));
					}
				}
				
				if (speed == 2) {
					block2 = new BlockWithId(0,new TurnLeft(2));
				}				
			}
			else {
				if (speed == 2) {
					block2 = new BlockWithId(0,new TurnLeft(2));
				}
				else if (speed == 3) {
					block2 = new BlockWithId(0,new TurnLeft(5));
				}
			}
			
			if (speed == 1) {
				block2 = new BlockWithId(0,new TurnLeft(1));
			}
		break;
		
		case "TurnRight":
			if (/^\d+$/.test(mouvs[i+1])) {
				if (parseInt(mouvs[i+1]) % 2 == 0) {																																	
					if (speed == 3) {
						block2 = new BlockWithId(0,new TurnRight(parseInt(mouvs[i+1])/2));
					}					
				}					
				else {
					if (speed == 3) {
						block2 = new BlockWithId(0,new TurnRight(Math.floor(parseInt(mouvs[i+1])/2)));
					}
				}
				
				if (speed == 2) {
					block2 = new BlockWithId(0,new TurnRight(2));
				}				
			}
			else {
				if (speed == 2) {
					block2 = new BlockWithId(0,new TurnRight(2));
				}
				else if (speed == 3) {
					block2 = new BlockWithId(0,new TurnRight(5));
				}
			}
			
			if (speed == 1) {
				block2 = new BlockWithId(0,new TurnRight(1));
			}
		break;
		
		case "Wait":
			if (/^\d+$/.test(mouvs[i+1])) {
				block2 = new BlockWithId(0,new ControlWait(parseInt(mouvs[i+1])));
			}							
			else {
				block2 = new BlockWithId(0,new ControlWait());
			}		
		break;
		
		case "Grow":
			if (/^\d+$/.test(mouvs[i+1])) {
				block2 = new BlockWithId(0,new ChangeCostumeSize(parseInt(mouvs[i+1])));
			}							
			else {
				block2 = new BlockWithId(0,new ChangeCostumeSize());
			}			
		break;
		
		case "Shrink":
			if (/^\d+$/.test(mouvs[i+1])) {
				block2 = new BlockWithId(0,new ChangeCostumeSize(-parseInt(mouvs[i+1])));
			}							
			else {
				block2 = new BlockWithId(0,new ChangeCostumeSize(-5));
			}			
		break;
		
		case "NormalSize":
			block2 = new BlockWithId(0,new ResetCostumeSize());
		break;			
		
		case "Show":
			block2 = new BlockWithId(0,new Show());
		break;
		
		case "Hide":
			block2 = new BlockWithId(0,new Hide());
		break;

		case "ChangeScene":
			if (/^\d+$/.test(mouvs[j+1])) {
				id = generateId();
				block2 = new BlockWithId(0,new SwitchToBackdrop(id));
				sprite.blocks[block2.id] = block2.block;								
				
				if (mouvs[j+1] == "1")
					block2 = new BlockWithId(id,new Backdrop(scenes_list[0]));
				if (mouvs[j+1] == "2")
					block2 = new BlockWithId(id,new Backdrop(scenes_list[1]));
				if (mouvs[j+1] == "3")
					block2 = new BlockWithId(id,new Backdrop(scenes_list[2]));							
			}
		break;			
	}		
	sprite.blocks[block2.id] = block2.block;
	return block2;	
}
// création blocs Scratch composés de boucles. ex : mouvement composé de boucle
// pour simuler le mouvement fluide, sinon mouvement trop rapide
function create_block_loop(mouvs,sprite,prec_block,_i,speed,block_name,loop_blocks) {
	var bloc;
	var i = _i;
	id = generateId();

	var block2 = create_block(mouvs,sprite,block_name,i,speed);
	
	if (block_name == "Wait" || block_name == "Grow" || block_name == "Shrink" || block_name == "NormalSize"
	|| block_name == "Show" || block_name == "Hide" || block_name == "ChangeScene") {
		if (/^\d+$/.test(mouvs[i+1])) {
			i = i+2;
		}
		else {
			i++;
		}
		if (prec_block != null) block2.parent(prec_block);
		return [block2,i];
	}
	else {		
		if (/^\d+$/.test(mouvs[i+1])) {
			if (speed == 2 || speed == 3) {
				if (parseInt(mouvs[i+1]) % 2 == 0) {
					if (speed == 2) 
						bloc = new BlockWithId(id,new ControlRepeat(parseInt(mouvs[i+1])/2,[block2],id));
					else if (speed == 3)
						bloc = new BlockWithId(id,new ControlRepeat(2,[block2],id));
						
					if (prec_block != null) {
						bloc.parent(prec_block);
						prec_block = bloc;
					}
					sprite.blocks[bloc.id] = bloc.block;				
				}
				else {
					if (speed == 2) 
						bloc = new BlockWithId(id,new ControlRepeat(Math.floor(parseInt(mouvs[i+1])/2),[block2],id));
					sprite.blocks[bloc.id] = bloc.block;				
					if (prec_block != null) {					
						block2 = create_block(mouvs,sprite,block_name,i,1);						
						block2.parent(prec_block);
						sprite.blocks[block2.id] = block2.block;
						prec_block = block2;
					}
					else {				
						if (loop_blocks != null) {
							block2 = create_block(mouvs,sprite,block_name,i,1);
							loop_blocks.push(block2);
						}		
					}											
				}
			}		
			else if (speed == 1) {
				bloc = new BlockWithId(id,new ControlRepeat(parseInt(mouvs[i+1]),[block2],id));
				if (prec_block != null) bloc.parent(prec_block);
				//sprite.blocks[bloc.id] = bloc.block;
			}
			i = i+2;
		}							
		else {								
			if (speed == 2) {
				bloc = new BlockWithId(id,new ControlRepeat(5,[block2],id));
				if (prec_block != null) bloc.parent(prec_block);
			}
			else if (speed == 3) {
				bloc = new BlockWithId(id,new ControlRepeat(2,[block2],id));
				if (prec_block != null) bloc.parent(prec_block);
			}
			else if (speed == 1) {
				bloc = new BlockWithId(id,new ControlRepeat(10,[block2],id));
				if (prec_block != null) bloc.parent(prec_block);									
			}
			i++;			
		}
	}	
	return [bloc,i,loop_blocks];
}
// remplit l'objet sprite (blocs d'instruction du programme)
function GenerateSequencePerso(id_perso,stat,sprite1,sprite2,costume1_list,costume2_list) {
	var mouvs = stat.split(",");
	
	if (id_perso== 1)
		var sprite = sprite1;
	if (sprite2 != null && id_perso == 2)
			var sprite = sprite2;
	var id;
	var i = 1;
	var cur;	
	var mem;
	
	var add_not_block = false;
	var add_not_wait = true;
	var speed_changed = 1;
	
	var bloc;
	var block2;
	var prec_block;
	var loop_blocks = [];	
	
	var scenes_list = ["backdrop1","Basketball","Bedroom"];
	
	if (mouvs[mouvs.length-1] != "End") {
		alert("End manquant à la fin");
		return;		
	}
	
	if (mouvs[0] != "GreenFlag") {
		alert("Flag manquant au début");
		return;		
	}
	
	bloc = new BlockWithId(0,new FlagGreen());
	prec_block = bloc;
	sprite.blocks[bloc.id] = bloc.block
	block_prec = bloc;
	
	while (i <= mouvs.length-1) {
		if (mouvs[i] == "OpenRepeat")		
			[prec_block,i] = loop_detect(prec_block,i,mouvs,sprite,speed_changed,scenes_list);
		else {			
			switch (mouvs[i]) {
				case "End":
					add_not_block = true;
					if (i != mouvs.length-1) {
						alert("Bloc End mal placé");
						if (/^\d+$/.test(mouvs[i+1]))
							i = i+2;
						else								
							i++;
					}
					else
						i = mouvs.length;					 												
				break;
				
				case "HandUp":
					add_not_wait = false;
					[bloc,i] = create_block_loop(mouvs,sprite,prec_block,i,speed_changed,"HandUp",null);
					prec_block = bloc;
				break;
				
				case "HandBottom":
					[bloc,i] = create_block_loop(mouvs,sprite,prec_block,i,speed_changed,"HandBottom",null);
					prec_block = bloc;
				break;
				
				case "HandLeft":
					[bloc,i] = create_block_loop(mouvs,sprite,prec_block,i,speed_changed,"HandLeft",null);
					prec_block = bloc;
				break;
				
				case "HandRight":
					[bloc,i] = create_block_loop(mouvs,sprite,prec_block,i,speed_changed,"HandRight",null);
					prec_block = bloc;
				break;
				
				case "TurnLeft":
					[bloc,i] = create_block_loop(mouvs,sprite,prec_block,i,speed_changed,"TurnLeft",null);
					prec_block = bloc;
				break;
				
				case "TurnRight":
					[bloc,i] = create_block_loop(mouvs,sprite,prec_block,i,speed_changed,"TurnRight",null);
					prec_block = bloc;
				break;						
				
				case "Jump":
					mem = i;
					add_not_wait = true;
					
					[bloc,i] = create_block_loop(mouvs,sprite,prec_block,mem,speed_changed,"HandUp",null);
					bloc.parent(prec_block);
					sprite.blocks[bloc.id] = bloc.block;
					prec_block = bloc;
					
					[bloc,i] = create_block_loop(mouvs,sprite,prec_block,mem,speed_changed,"HandBottom",null);
					bloc.parent(prec_block);
					prec_block = bloc;
							
				break;
				
				case "Wait":							
					[bloc,i] = create_block_loop(mouvs,sprite,prec_block,i,speed_changed,"Wait",null);
					prec_block = bloc;			
				break;
				
				case "Grow":
					[bloc,i] = create_block_loop(mouvs,sprite,prec_block,i,speed_changed,"Grow",null);
					prec_block = bloc;
				break;
				
				case "Shrink":
					[bloc,i] = create_block_loop(mouvs,sprite,prec_block,i,speed_changed,"Shrink",null);
					prec_block = bloc;
				break;
				
				case "NormalSize":
					[bloc,i] = create_block_loop(mouvs,sprite,prec_block,i,speed_changed,"NormalSize",null);
					prec_block = bloc;
				break;
				
				case "Show":							
					[bloc,i] = create_block_loop(mouvs,sprite,prec_block,i,speed_changed,"Show",null);
					prec_block = bloc;																												
				break;
				
				case "Hide":
					[bloc,i] = create_block_loop(mouvs,sprite,prec_block,i,speed_changed,"Hide");
					prec_block = bloc;
				break;
				
				case "ChangeScene":
					add_not_block = true;
					if (/^\d+$/.test(mouvs[i+1])) {
						id = generateId();
						bloc = new BlockWithId(0,new SwitchToBackdrop(id));							
						bloc.parent(prec_block);
						sprite.blocks[bloc.id] = bloc.block;
						prec_block = bloc;
						
						if (mouvs[i+1] == "1")
							bloc = new BlockWithId(id,new Backdrop(scenes_list[0]));								
						if (mouvs[i+1] == "2")
							bloc = new BlockWithId(id,new Backdrop(scenes_list[1]));
						if (mouvs[i+1] == "3")
							bloc = new BlockWithId(id,new Backdrop(scenes_list[2]));
						bloc.parent(prec_block);
						sprite.blocks[bloc.id] = bloc.block;								
						
						i = i+2;
					}							
					else								
						i++;							
				break;

				case "Speed":
					if (/^\d+$/.test(mouvs[i+1])) {
						if (mouvs[i+1] == "1") {
							speed_changed = 1;
						}
						if (mouvs[i+1] == "2") {
							speed_changed = 2;
						}
						if (mouvs[i+1] == "3") {
							speed_changed = 3;
						}																	
						i = i+2;
					}							
					else {
						speed_changed = 1;
						i++;
					}																						
				break;
				
				case "Reset":
					add_not_block = true;
					bloc = new BlockWithId(0,new Gotoxy());							
					bloc.parent(prec_block);
					sprite.blocks[bloc.id] = bloc.block;
					prec_block = bloc;
					
					bloc = new BlockWithId(0,new PointInDirection(90));							
					bloc.parent(prec_block);
					sprite.blocks[bloc.id] = bloc.block;
					prec_block = bloc;
					
					bloc = new BlockWithId(0,new SetRotationStyle());							
					bloc.parent(prec_block);
					sprite.blocks[bloc.id] = bloc.block;
					prec_block = bloc;
					
					id = generateId();
					bloc = new BlockWithId(0,new SwitchCostumeTo(id));							
					bloc.parent(prec_block);
					sprite.blocks[bloc.id] = bloc.block;
					prec_block = bloc;
					
					if (id_perso == 1)
						bloc = new BlockWithId(id,new LooksCostume(costume1_list[0]));								
					if (id_perso == 2)
						bloc = new BlockWithId(id,new LooksCostume(costume2_list[0]));
					
					bloc.parent(prec_block);
					sprite.blocks[bloc.id] = bloc.block;
				
					if (/^\d+$/.test(mouvs[i+1]))							
						i = i+2;						
					else
						i++;
				break;
										
				case "TouchAnotherSprite":
					if (sprite2 != null) {
						var id_cond = generateId();
						var id_if_menu = generateId();
						var if_block;
						var prec_block2;
						id = generateId();
						
						bloc = new BlockWithId(0,new FlagGreen());
						sprite.blocks[bloc.id] = bloc.block;
						prec_block = bloc;
						
						bloc = new BlockWithId(0,new ControlIf(id_cond));
						prec_block2 = bloc;
						if_block = bloc;
						sprite.blocks[bloc.id] = bloc.block;
						
						bloc = new BlockWithId(id_cond,new SensingTouchingObject(id_if_menu));
						bloc.onlyParentById(prec_block2.id);
						sprite.blocks[bloc.id] = bloc.block;
						prec_block2 = bloc;
						
						if (id_perso == 1)
							bloc = new BlockWithId(id_if_menu,new SensingTouchingObjectMenu(sprite2));
						if (id_perso == 2)
							bloc = new BlockWithId(id_if_menu,new SensingTouchingObjectMenu(sprite1));
						bloc.onlyParentById(prec_block2.id);
						sprite.blocks[bloc.id] = bloc.block;
						
						bloc = new BlockWithId(id,new ControlForever([if_block],id));
						bloc.parent(prec_block);
						sprite.blocks[bloc.id] = bloc.block;
						prec_block = bloc;
					}
					if (/^\d+$/.test(mouvs[i+1]))
						i = i+2;						
					else							
						i++;							
				break;
				
				default:
					add_not_block = true;
					if (/^\d+$/.test(mouvs[i+1]))
						i = i+2;						
					else							
						i++;
				break;						
			}
					
			if (!add_not_block) {				
				sprite.blocks[bloc.id] = bloc.block;
				bloc = new BlockWithId(0,new ControlWait(0.5));
				bloc.parent(prec_block);
				sprite.blocks[bloc.id] = bloc.block;
				prec_block = bloc;
			}			
			if (add_not_block) add_not_block = false;
			if (!add_not_wait) add_not_wait = true;
		}
	}
	return sprite;	
}
// même rôle que GenerateSequencePerso mais pour une boucle
function loop_detect(prec_block,i,mouvs,_sprite,speed_changed,scenes_list) {
	var cur = recherche_end_boucle(mouvs,i+1);
	var add_not_block = false;
	var add_not_wait = true;	
	
	var j = i+1;
	var mem;
	
	var bloc;
	var block2;
	var loop_blocks = [];
	
	var sprite = _sprite;
	
	if (cur != 0) {			
		while (j < cur) {						
			switch (mouvs[j]) {						
				case "End":
					add_not_block = true;						
					j = cur;						
				break;
				
				case "HandUp":
					if (j+1 != cur-1)
						[bloc,j,loop_blocks] = create_block_loop(mouvs,sprite,null,j,speed_changed,"HandUp",loop_blocks);						
					else {
						bloc = new BlockWithId(0,new Changeyby());
						j = j+2;
					}
				break;
				
				case "HandBottom":
					if (j+1 != cur-1)
						[bloc,j,loop_blocks] = create_block_loop(mouvs,sprite,null,j,speed_changed,"HandBottom",loop_blocks);
					else {
						bloc = new BlockWithId(0,new Changeyby(-10));
						j = j+2;
					}
				break;
				
				case "HandLeft":
					if (j+1 != cur-1)
						[bloc,j,loop_blocks] = create_block_loop(mouvs,sprite,null,j,speed_changed,"HandLeft",loop_blocks);
					else {
						bloc = new BlockWithId(0,new Changexby(-10));
						j = j+2;
					}
				break;
				
				case "HandRight":
				alert("ok");
					if (j+1 != cur-1)
						[bloc,j,loop_blocks] = create_block_loop(mouvs,sprite,null,j,speed_changed,"HandRight",loop_blocks);				
					else {
						bloc = new BlockWithId(0,new Changexby());
						j = j+2;
					}
					alert(bloc.block.opcode);
				break;
				
				case "TurnLeft":
					if (j+1 != cur-1)
						[bloc,j,loop_blocks] = create_block_loop(mouvs,sprite,null,j,speed_changed,"TurnLeft",loop_blocks);
					else {
						bloc = new BlockWithId(0,new TurnLeft());
						j = j+2;
					}
				break;
				
				case "TurnRight":
					if (j+1 != cur-1)
						[bloc,j,loop_blocks] = create_block_loop(mouvs,sprite,null,j,speed_changed,"TurnRight",loop_blocks);
					else {
						bloc = new BlockWithId(0,new TurnRight());
						j = j+2;
					}
				break;
					
				case "Jump":
					if (j+1 != cur-1) {
						mem = j;
						[bloc,j,loop_blocks] = create_block_loop(mouvs,sprite,null,mem,speed_changed,"HandUp",loop_blocks);
						sprite.blocks[bloc.id] = bloc.block;
						loop_blocks.push(bloc);
						
						[bloc,j] = create_block_loop(mouvs,sprite,null,mem,speed_changed,"HandBottom",loop_blocks);
						sprite.blocks[bloc.id] = bloc.block;
						loop_blocks.push(bloc);
					}
					else {
						mem = j;
						var mem2 = mouvs[j+1];
						mouvs[mem+1] = "";
						
						[bloc,j] = create_block_loop(mouvs,sprite,null,mem,speed_changed,"HandUp",loop_blocks);
						sprite.blocks[bloc.id] = bloc.block;
						loop_blocks.push(bloc);
						
						[bloc,j] = create_block_loop(mouvs,sprite,null,mem,speed_changed,"HandBottom",loop_blocks);

						mouvs[mem+1] = mem2;
					}
				break;
				
				case "Wait":
					[bloc,j] = create_block_loop(mouvs,sprite,null,j,speed_changed,"Wait");					
				break;
				
				case "Grow":
					[bloc,j] = create_block_loop(mouvs,sprite,null,j,speed_changed,"Grow");
				break;
				
				case "Shrink":
					[bloc,j] = create_block_loop(mouvs,sprite,null,j,speed_changed,"Shrink");
				break;
				
				case "NormalSize":
					[bloc,j] = create_block_loop(mouvs,sprite,null,j,speed_changed,"NormalSize");
				break;
									
				case "Show":
					[bloc,j] = create_block_loop(mouvs,sprite,null,j,speed_changed,"Show");																					
				break;
				
				case "Hide":
					[bloc,j] = create_block_loop(mouvs,sprite,null,j,speed_changed,"Hide");
				break;

				case "ChangeScene":						
					if (/^\d+$/.test(mouvs[j+1])) {
						id = generateId();
						bloc = new BlockWithId(0,new SwitchToBackdrop(id));
						sprite.blocks[bloc.id] = bloc.block;								
						loop_blocks.push(bloc);
						
						if (mouvs[j+1] == "1")
							bloc = new BlockWithId(id,new Backdrop(scenes_list[0]));
						if (mouvs[j+1] == "2")
							bloc = new BlockWithId(id,new Backdrop(scenes_list[1]));
						if (mouvs[j+1] == "3")
							bloc = new BlockWithId(id,new Backdrop(scenes_list[2]));							
						j = j+2;
					}							
					else								
						i++;							
				break;
				
				case "Speed":
					add_not_block = true;
					if (/^\d+$/.test(mouvs[j+1])) {
						if (mouvs[j+1] == "1") {
							speed_changed = 1;
						}
						if (mouvs[j+1] == "2") {
							speed_changed = 2;
						}
						if (mouvs[j+1] == "3") {
							speed_changed = 3;
						}																	
						j = j+2;
					}							
					else {
						speed_changed = 1;
						j++;
					}																						
				break;																
				
				default:
					add_not_block = true;
					if (/^\d+$/.test(mouvs[j+1]))
						j = j+2;						
					else							
						j++;
				break;
			}							
			
			if (j <= cur && !add_not_block) {				
				loop_blocks.push(bloc);
				sprite.blocks[bloc.id] = bloc.block;

				bloc = new BlockWithId(0,new ControlWait(0.5));
				loop_blocks.push(bloc);
				sprite.blocks[bloc.id] = bloc.block;
			}						
			
			if (add_not_block) add_not_block = false;
		}
		
		id = generateId();			
		
		if (loop_blocks.length != 0) {
			bloc = new BlockWithId(id,new ControlRepeat(parseInt(mouvs[cur-1]),loop_blocks,id));
			bloc.parent(prec_block);
			sprite.blocks[bloc.id] = bloc.block;
			prec_block = bloc;																
			loop_blocks = [];
			i = cur + 1;
		}
		else
			i = cur+1;																			
	}
	else return;
	return [prec_block,cur+1];
}
// génère un id alétatoire de taille 20 pour chaque bloc
function generateId() {
	var text = "";
	var possible = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
	for (var i = 0; i < 20; i++)
		text += possible.charAt(Math.floor(Math.random() * possible.length));
	return text;
}
